// form-animations.js
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registrationForm');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirm_password');
    const submitBtn = document.querySelector('.btn-submit');
    
    // Add real-time validation feedback
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            validatePasswordStrength(this.value);
        });
    }
    
    if (confirmPasswordInput && passwordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            validatePasswordMatch(passwordInput.value, this.value);
        });
    }
    
    // Form submission animation
    if (form) {
        form.addEventListener('submit', function(e) {
            // Only add animation if form is valid
            if (this.checkValidity()) {
                submitBtn.classList.add('loading');
                submitBtn.innerHTML = 'Processing...';
                
                // Remove loading class after form submission (simulate)
                setTimeout(function() {
                    submitBtn.classList.remove('loading');
                    submitBtn.innerHTML = 'Register';
                }, 2000);
            }
        });
    }
    
    // Input focus animations
    const inputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="password"]');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.querySelector('label').style.color = '#6a11cb';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.querySelector('label').style.color = '#34495e';
        });
    });
    
    // Function to validate password strength in real-time
    function validatePasswordStrength(password) {
        const strengthIndicator = document.getElementById('passwordStrength') || createPasswordStrengthIndicator();
        
        if (password.length === 0) {
            strengthIndicator.className = 'password-strength';
            strengthIndicator.style.width = '0';
            return;
        }
        
        let strength = 0;
        
        // Check for length
        if (password.length >= 8) strength += 1;
        
        // Check for uppercase letters
        if (/[A-Z]/.test(password)) strength += 1;
        
        // Check for lowercase letters
        if (/[a-z]/.test(password)) strength += 1;
        
        // Check for numbers
        if (/[0-9]/.test(password)) strength += 1;
        
        // Check for special characters
        if (/[@$!%*?&]/.test(password)) strength += 1;
        
        // Update strength indicator
        if (strength <= 2) {
            strengthIndicator.className = 'password-strength strength-weak';
        } else if (strength <= 4) {
            strengthIndicator.className = 'password-strength strength-medium';
        } else {
            strengthIndicator.className = 'password-strength strength-strong';
        }
    }
    
    // Function to create password strength indicator if it doesn't exist
    function createPasswordStrengthIndicator() {
        const passwordGroup = passwordInput.parentElement;
        const strengthIndicator = document.createElement('div');
        strengthIndicator.id = 'passwordStrength';
        strengthIndicator.className = 'password-strength';
        passwordGroup.appendChild(strengthIndicator);
        return strengthIndicator;
    }
    
    // Function to validate password match in real-time
    function validatePasswordMatch(password, confirmPassword) {
        if (confirmPassword.length === 0) return;
        
        if (password === confirmPassword) {
            confirmPasswordInput.classList.add('valid');
            confirmPasswordInput.classList.remove('invalid');
        } else {
            confirmPasswordInput.classList.add('invalid');
            confirmPasswordInput.classList.remove('valid');
        }
    }
});